export class Doctor{
    id?:number;
	appointmentDate:string;
	session:string;
	slot:string;
	speciality:string;
	consultants:string;
	timing:string;
    status:string;
}